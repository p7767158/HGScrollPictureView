//
//  ViewController.m
//  lunbo
//
//  Created by zhh on 15/12/17.
//  Copyright © 2015年 zhh. All rights reserved.
//

#import "ViewController.h"
#import "HGScrollPictureView.h"
#import "HGViewController.h"
@interface ViewController ()<HGScrollPictureViewDelegate>
@property (nonatomic, strong) HGScrollPictureView *picView;
@end

@implementation ViewController

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    [self.picView startScroll];
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [self.picView pauseScroll];
}

- (void)viewDidLoad {
    [super viewDidLoad];
//    NSArray *images = @[[UIImage imageNamed:@"1.jpg"],[UIImage imageNamed:@"2.jpg"],[UIImage imageNamed:@"3.jpg"]];
//    self.picView = [[ScrollPictureView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 260) images:images isAutoScroll:YES];
    
    
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeSystem];
    [btn setTitle:@"next" forState:UIControlStateNormal];
    btn.frame = CGRectMake(50, 300, 80, 40);
    [self.view addSubview:btn];
    [btn addTarget:self action:@selector(next) forControlEvents:UIControlEventTouchUpInside];
    
    NSArray *urlStrings = @[@"http://wahoolimg.oss-cn-beijing.aliyuncs.com/upload/6c8d711261a24ec14bbfd1f26d67da14.jpg", @"http://wahoolimg.oss-cn-beijing.aliyuncs.com/upload/febf3ea7714a0f715323a11f5d4fb0bf.jpg", @"http://wahoolimg.oss-cn-beijing.aliyuncs.com/upload/a16f816f56fccffd0a8b302c03fc4832.jpg"];
    [HGScrollPictureView scrollPictureViewWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 260) urlStrings:urlStrings isAutoScroll:YES block:^(HGScrollPictureView *scrollPictureView) {
        self.picView = scrollPictureView;
        self.picView.delegate = self;
        [self.picView setPageControllFrame:CGRectMake(0, 0, 100, 30)];
        [self.picView setPageIndicatorTintColor:[UIColor yellowColor]];
        [self.picView setCurrentPageIndicatorTintColor:[UIColor redColor]];
        [self.view addSubview:self.picView];
    }];
    
}

- (void)next
{
    [self presentViewController:[[HGViewController alloc] init] animated:YES completion:nil];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - ScrollPictureViewDelegate

- (void)scrollPictureView:(HGScrollPictureView *)scrollPictureView didSelectedItemAtIndex:(NSInteger)index
{
    NSLog(@"selected %ld",index);
}

//如果需要更精确的index可以观察我暴漏出来的pageControll的currentPage属性
- (void)scrollPictureView:(HGScrollPictureView *)scrollPictureView didScorllingAtIndex:(NSInteger)index
{
    NSLog(@"scroll %ld",index);
}
@end
