//
//  HGViewController.h
//  lunbo
//
//  Created by zhh on 15/12/17.
//  Copyright © 2015年 zhh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HGViewController : UIViewController

@end
